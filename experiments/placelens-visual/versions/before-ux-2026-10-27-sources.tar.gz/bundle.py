"""Build one offline HTML file; writes only PlaceLens-visual.html next to this file."""
import base64
from pathlib import Path

root = Path(__file__).resolve().parent
html = (root / 'index.html').read_text()
font = base64.b64encode((root / 'assets/GolosText-variable.ttf').read_bytes()).decode()
for name in ('style.css', 'visual.css'):
    css = (root / name).read_text().replace(
        'url("assets/GolosText-variable.ttf")',
        f'url("data:font/ttf;base64,{font}")',
    )
    html = html.replace(f'<link rel="stylesheet" href="{name}">', f'<style>\n{css}\n</style>')

scripts = []
for name in ('app.js', 'visual.js'):
    html = html.replace(f'  <script src="{name}" defer></script>\n', '')
    scripts.append('<script>\n' + (root / name).read_text() + '\n</script>')

# Preserve separate classic script scopes: the second script replaces presentation functions.
license_text = (root / 'assets/OFL-Golos-Text.txt').read_text()
scripts.append('<script type="text/plain" id="golos-text-license">\n' + license_text + '\n</script>')
html = html.replace('href="./index.html"', 'href="./PlaceLens-visual.html"')
html = html.replace('</body>', '\n'.join(scripts) + '\n</body>')
(root / 'PlaceLens-visual.html').write_text(html)
