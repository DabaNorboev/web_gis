/* A visual design hypothesis: personal thresholds are demo UI, not a production capability. */
state.limits = {};
state.stopLimit = 250;
state.focusGoal = null;
state.mapMode = 'all';
state.envFocus = null;
state.mobileConfigure = false;

function icon(name, size = 20) {
  const paths = {
    walk:'<circle cx="14" cy="4" r="2"/><path d="m8 10 4-3 3 4 4 1M12 8l-2 6-4 6m4-6 5 2 1 5M5 12l3-2"/>',
    car:'<path d="m5 8 2-4h10l2 4M3 10l2-2h14l2 2v8H3Zm2 8v3m14-3v3M3 13h18M7 11v1m10-1v1"/>',
    bus:'<rect x="5" y="3" width="14" height="16" rx="3"/><path d="M5 11h14M9 3v8m6-8v8M8 19v2m8-2v2M8 15h1m6 0h1"/>',
    park:'<path d="m12 2-5 7h3l-5 7h6v6h2v-6h6l-5-7h3Z"/>',
    green:'<path d="M20 3C8 1 2 7 5 15c9 5 17-2 15-12ZM5 20 16 8"/>',
    road:'<path d="M7 2 4 22m13-20 3 20M12 3v4m0 3v4m0 3v4"/>',
    water:'<path d="M12 2C10 6 5 11 5 15a7 7 0 0 0 14 0c0-4-5-9-7-13ZM9 16c0 2 1 3 3 3"/>',
    rail:'<rect x="5" y="3" width="14" height="15" rx="4"/><path d="M5 10h14M9 3v7m6-7v7M8 14h1m6 0h1M8 18l-3 4m11-4 3 4M7 21h10"/>',
    work:'<rect x="3" y="7" width="18" height="14" rx="3"/><path d="M8 7V3h8v4M3 13c6 3 12 3 18 0m-9-1v5"/>',
    sport:'<path d="m4 7 13 13M2 9l7-7m6 20 7-7M2 5l3-3m14 20 3-3M5 14l9-9"/>',
    study:'<path d="m2 8 10-5 10 5-10 5ZM6 10v7c4 3 8 3 12 0v-7m4-2v9"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
    target:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 1v3m11 8h-3M12 23v-3M1 12h3"/>',
    map:'<path d="m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2Zm6-2v16m6-14v16"/>',
    arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
    unknown:'<path d="M9 8a3 3 0 0 1 6 0c0 3-3 2-3 5m0 4h.01"/><circle cx="12" cy="12" r="10"/>'
  };
  return `<svg class="ui-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||paths.target}</svg>`;
}
function goalIcon(g) {return g.id.includes('work')?'work':g.id.includes('sport')?'sport':g.id.includes('study')?'study':'target';}
function limitKey(g){return (state.scenario==='standalone'?'s:':'p:')+g.id;}
function goalLimit(g){return state.limits[limitKey(g)] ?? 20;}
function timeStatus(t,g){return !t||t.status!=='available'?'unknown':t.minutes<=goalLimit(g)?'within':'over';}
function thresholdBar(value, limit, scale, tone, label){
  if(value==null)return `<div class="visual-bar unknown-bar" role="img" aria-label="${escapeHTML(label)}: значение неизвестно, это не ноль"><span>?</span></div>`;
  const neutral=tone.startsWith('neutral');
  const max=Math.max(scale,limit*1.25,value*1.05);
  const width=value/max*100, mark=limit/max*100;
  return `<div class="visual-bar ${tone}" role="img" aria-label="${escapeHTML(label)}: ${value}, ${neutral?'радиус анализа':'ваш ориентир'} ${limit}"><i class="bar-fill" style="width:${Math.min(width,100)}%"></i>${value>limit?`<i class="bar-overflow ${neutral?'outside-radius':''}" style="left:${mark}%;width:${width-mark}%"></i>`:''}<b class="limit-mark" style="left:${mark}%"></b></div>`;
}
function statusLabel(t,g,brief=false){
  if(!t)return brief?'—':'Не рассчитано';
  if(t.status==='loading')return brief?'…':'Считаем';
  if(t.status==='refine')return brief?'? улица':'Нужна улица';
  if(t.status==='error')return brief?'? сбой':'Нужен повтор';
  const delta=t.minutes-goalLimit(g);
  return delta>0?`+${delta} мин`:brief?'✓':`В ориентире`;
}
function goalList(){
  return selectedGoals().map((g,i)=>`<div class="goal-item visual-goal-item" data-goal-row="${g.id}"><span class="goal-icon">${icon(goalIcon(g))}</span><div class="goal-body"><button class="goal-text" data-action="edit-goal" data-goal="${g.id}"><strong>${escapeHTML(g.label)}</strong><small>${escapeHTML(g.address)}</small></button><button class="goal-limit" data-action="thresholds" data-goal="${g.id}">${icon('clock',15)} До <b>${goalLimit(g)}</b> мин <span>✎</span></button></div><button class="remove" data-action="remove-goal" data-goal="${g.id}" aria-label="Удалить цель ${escapeHTML(g.label)}">×</button></div>`).join('');
}
function renderSetup(){
  $('.mobile-selection')?.remove();
  baseRenderSetup();
  $('.side-intro h1').innerHTML=state.a||state.b?'Ваше сравнение':'Ближе к вашей<br>повседневности';
  const fields=$('.trip-fields');if(fields){const mode=$('.mode',fields);const list=$('.goal-list',fields);if(mode&&list)fields.insertBefore(mode,list);}
  if(state.scenario==='places'){
    const transport=document.createElement('button');
    transport.className='transport-limit';transport.dataset.action='thresholds';transport.dataset.goal='stops';
    transport.innerHTML=`<span class="transport-limit-icon">${icon('bus',22)}</span><span><strong>До остановки</strong><small>Ваш ориентир · по прямой</small></span><b>${state.stopLimit}<small> м</small> <span>✎</span></b>`;
    const line=$('.section-line',$('#setup'));line.before(transport);
  }
  if(state.scenario==='places'&&(state.a||state.b)){
    const compact=document.createElement('div');compact.className='mobile-selection';compact.innerHTML=`<div class="selection-pair">${['a','b'].map(s=>state[s]?`<button data-action="select-side" data-side="${s}" class="${state.active===s?'selected':''}">${badge(s)}<strong>${escapeHTML(state[s].address)}</strong></button>`:`<button data-action="search-address" data-side="${s}"><span class="badge ${s==='b'?'b':''}">+</span><strong>Добавить ${sideLabel(s)}</strong></button>`).join('')}</div><div class="compact-controls"><span>${icon(state.mode==='walking'?'walk':'car',17)} ${state.mode==='walking'?'Пешком':'Авто'} · ${selectedGoals().length} цели</span><button data-action="mobile-settings" aria-expanded="${state.mobileConfigure}">${state.mobileConfigure?'Скрыть настройки ↑':'Настроить ↓'}</button></div>`;$('#setup').before(compact);
  }
  $('.sidebar').classList.toggle('mobile-configure',state.mobileConfigure);
  $('.sidebar').classList.toggle('has-selection',state.scenario==='places'&&!!(state.a||state.b));
  $('.sidebar').classList.toggle('has-goals',selectedGoals().length>0);
  const toggle=$('[data-action="toggle-trip-setup"]');if(toggle)toggle.innerHTML=`<span>${selectedGoals().length} цели · ${state.mode==='walking'?'Пешком':'Авто'}</span><span>Ориентиры ↓</span>`;
}
function mapTime(g,s){const t=selectedTrips()[`${s}:${g.id}`];return `<span class="map-time ${timeStatus(t,g)}"><i class="side-letter ${s}">${s==='s'?'С':sideLabel(s)}</i><b>${t?.status==='available'?t.minutes:'?'}</b>${t?.status==='available'?'<small>мин</small>':''}<em>${statusLabel(t,g,true)}</em></span>`;}
function mapGoal(g){
  const i=selectedGoals().findIndex(x=>x.id===g.id);
  if(innerWidth<=760&&selectedGoals().length===3){const pos=[{x:46,y:45},{x:83,y:82},{x:26,y:65}][i];return {...g,...pos};}
  if(innerWidth<=760&&i===0)return {...g,x:46,y:77};
  if(innerWidth<=760&&i===1)return {...g,x:83,y:55};
  if(innerWidth>760&&i===2)return {...g,y:75};
  return g;
}
function mapHouse(h,s){if(innerWidth>760||state.scenario!=='places')return h;if(selectedGoals().length===3)return {...h,y:s==='a'?31:18};return {...h,y:s==='a'?38:22};}
function renderMap(){
  const places=state.scenario==='places',sides=selectedSides();
  ['a','b'].forEach(s=>{const circle=$(`#radius-${s}`),h=state[s];circle.style.display=places&&h?'':'none';if(h){circle.setAttribute('cx',mapHouse(h,s).x*10);circle.setAttribute('cy',mapHouse(h,s).y*3.7);}circle.setAttribute('r',state.radius===500?103:65);});
  const marker=(h,s)=>s==='s'?`<button class="marker address-map-marker" style="left:${h.x}%;top:${h.y}%" data-action="pick-start" aria-label="Изменить произвольный старт"><span class="badge goal">С</span><span class="address-map-label"><strong>Ваш старт</strong><small>${h.id?escapeHTML(h.address):'Точка без адреса'}</small></span></button>`:`<button class="marker address-map-marker ${s==='b'?'b':''} ${state.active===s?'active':''}" style="left:${mapHouse(h,s).x}%;top:${mapHouse(h,s).y}%" data-action="select-side" data-side="${s}" aria-label="Адрес ${sideLabel(s)} на карте: ${escapeHTML(h.address)}">${badge(s)}<span class="address-map-label"><strong>${escapeHTML(h.address.replace('проспект','пр.').replace('ул. ','ул. '))}</strong><small class="${(s==='a'?140:290)<=state.stopLimit?'within':'over'}">${icon('bus',13)} <b>${state.profiles[s]==='ready'?(s==='a'?140:290)+' м':'? остановка'}</b><span>${state.profiles[s]==='ready'?((s==='a'?140:290)<=state.stopLimit?'✓':'+'+((s==='a'?140:290)-state.stopLimit)+' м'):'?'}</span></small></span></button>`;
  let html=places?sides.map(s=>marker(getHouse(s),s)).join(''):state.scenario==='standalone'&&state.start?marker(state.start,'s'):'';
  if(state.scenario!=='point')html+=selectedGoals().map((g,i)=>`<button class="marker goal-map-marker ${state.focusGoal===g.id?'focused':''} ${mapGoal(g).x>68?'align-right':mapGoal(g).x<30?'align-left':''}" style="left:${mapGoal(g).x}%;top:${mapGoal(g).y}%" data-action="focus-goal" data-goal="${g.id}" aria-pressed="${state.focusGoal===g.id}" aria-label="${escapeHTML(g.label)} на карте, ориентир ${goalLimit(g)} минут"><span class="goal-map-label"><span class="map-goal-heading">${icon(goalIcon(g),17)}<strong>${escapeHTML(g.label)}</strong><small>до ${goalLimit(g)}′</small></span><span class="map-times">${sides.map(s=>mapTime(g,s)).join('')}</span></span></button>`).join('');
  if(state.scenario==='point'&&state.point)html+=`<span class="point-spot" style="left:${state.point.x}%;top:${state.point.y}%" role="img" aria-label="Произвольная точка без адреса"></span>`;
  $('#map-markers').innerHTML=html;$('#map').classList.toggle('three-goals',state.scenario!=='point'&&selectedGoals().length===3);
  $('.map-section').classList.toggle('point-context',state.scenario==='point');
  $('.map-model-note').textContent=state.scenario==='point'?'Официальные остановки · расстояния по прямой.':state.mode==='walking'?'Линии и минуты — модель уличной части. Подходы от объектов неизвестны.':'Автомобильная модель без пробок и парковки. Подъезды не подтверждены.';
  $('.map-legend').innerHTML=state.scenario==='standalone'?'<span><i class="legend-dot a"></i> Старт</span><span><i class="legend-goal"></i> Цели поездок</span>':'<span><i class="legend-dot a"></i> Адрес А</span><span><i class="legend-dot b"></i> Адрес Б</span><span><i class="legend-goal"></i> Цель поездки</span><span class="map-hint">Выберите цель: карта и таблица подсветят её вместе</span>';
  const entries=state.scenario==='point'?[]:Object.entries(selectedTrips()).filter(([key,t])=>t.status==='available'&&(state.mapMode==='all'||key===state.selectedTrip||(!state.selectedTrip&&t.goal===state.focusGoal)));
  $('#route-lines').style.display=entries.length?'':'none';$('#route-lines').style.opacity='1';
  $('#route-lines').innerHTML=entries.map(([key,t])=>{
    const house=getHouse(t.side),goal=selectedGoals().find(g=>g.id===t.goal);if(!house||!goal)return '';const h=mapHouse(house,t.side),g=mapGoal(goal);
    const i=selectedGoals().indexOf(goal),sx=h.x*10+14,sy=h.y*3.7+16,tx=g.x*10+(t.side==='b'?10:-10),ty=g.y*3.7+28;
    const mid=sx+(tx-sx)*.45+(t.side==='b'?14:-14);
    const d=`M${sx} ${sy} L${mid} ${sy-20-i*12} L${mid+20} ${ty-18} L${tx} ${ty}`;
    const color=t.side==='b'?'#bc6841':'#6a55ae';const focus=state.focusGoal?state.focusGoal===g.id:state.selectedTrip?key===state.selectedTrip:true;
    return `<g opacity="${focus?1:.18}"><path d="${d}" stroke="white" stroke-width="9"/><path d="${d}" stroke="${color}" stroke-width="4.5" ${t.side==='b'?'stroke-dasharray="10 6"':''}/><circle cx="${sx}" cy="${sy}" r="5" fill="white" stroke="${color}" stroke-width="3"/><circle cx="${tx}" cy="${ty}" r="5" fill="white" stroke="${color}" stroke-width="3"/></g>`;
  }).join('');
  const context=state.focusGoal&&selectedGoals().find(g=>g.id===state.focusGoal);
  $('#map-context').textContent=state.pick?'Выберите точку на схеме':context?`${context.label} · до ${goalLimit(context)} мин`:state.scenario==='point'?'Остановки вокруг точки':`${state.radius} м вокруг адресов`;
  $('.map-section').classList.toggle('point-picker',!!state.pick);
  $('#map-art').style.transform='none';
  $('#map').classList.toggle('highlight-parks',state.envFocus==='park'||state.envFocus==='green');
  $('#map').classList.toggle('highlight-stops',state.envFocus==='stops'||state.envFocus==='count');
  if(state.pick){$('#map-callout').hidden=false;$('#map-callout').innerHTML=`<button class="close-callout icon-button" data-action="cancel-pick" aria-label="Отменить выбор">×</button><h3>Укажите точку на схеме</h3><p>${state.pick.kind==='street'?'Исходный объект сохраняется. Подход к улице неизвестен.':'Точка не получает выдуманный адрес.'}</p><button class="primary full" data-action="confirm-map-point">Выбрать демо-точку здесь</button>`;}else $('#map-callout').hidden=true;
  $('#map-selection').innerHTML=state.focusGoal?`<button data-action="clear-focus">Все цели <span>×</span></button>`:'';
  document.querySelectorAll('[data-action="map-mode"]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.value===state.mapMode));
}
function metricRaw(m,s){let v=m[s];if(m.id==='count'&&state.radius===300)v=s==='a'?3:5;if(m.id==='green'&&state.radius===300&&s==='a')v=12;if(state[s]&&!['demo-house-1','demo-house-2'].includes(state[s].id)&&v!=null&&m.unit==='м')v+=70;return v;}
function metricValue(m,s){
  if(state.profiles[s]==='loading')return '<div class="skeleton"></div><div class="skeleton short"></div>';
  if(state.profiles[s]==='error')return '<span class="unknown visual-unknown">? Недоступно</span><div class="visual-bar unknown-bar"></div>';
  const v=metricRaw(m,s),unknown=v==null;
  if(unknown)return `<span class="visual-unknown">${icon('unknown',20)} Нет данных</span>${thresholdBar(null,0,100,'unknown','Растительность')}<span class="metric-note">Неполное покрытие</span>`;
  const display=v>=1000?(v/1000).toLocaleString('ru-RU',{maximumFractionDigits:2}):v;
  const unit=v>=1000?'км':m.unit;
  const stop=m.id==='stops',limit=stop?state.stopLimit:state.radius;
  const max=Math.max(...['a','b'].filter(x=>state[x]).map(x=>metricRaw(m,x)||0),limit);
  const tone=stop?(v<=limit?'within':'over'):'neutral-'+s;
  const bar=m.unit==='%'?`<div class="visual-bar neutral-${s}"><i class="bar-fill" style="width:${v}%"></i></div>`:thresholdBar(v,limit,max*1.15,tone,m.plainName||m.name);
  const note=stop?v<=limit?`✓ До ${limit} м`:`+${v-limit} м к ориентиру`:m.id==='park'&&v>state.radius?'За кругом анализа':m.id==='road'?'Не измеряет шум':m.id==='green'?'Доля в круге':m.id==='count'?'В круге анализа':m.id==='rail'?'Движение неизвестно':'Доступ неизвестен';
  return `<strong class="metric-value value-${s}">${display}<small>${unit}</small></strong>${bar}<span class="visual-verdict ${stop?tone:''}">${note}</span>`;
}
const metricLabels={stops:['bus','Остановка','По прямой'],count:['bus','Остановки','В радиусе'],park:['park','Парк','До границы · по прямой'],green:['green','Растительность','Доля в круге'],road:['road','Крупная дорога','По прямой · не шум'],water:['water','Вода','До границы · по прямой'],rail:['rail','Железная дорога','По прямой']};
function environmentView(compact=false){
  const sides=selectedSides(),ms=compact?metrics.filter(m=>['stops','park','green','road'].includes(m.id)):metrics;
  return `${sides.filter(s=>state.profiles[s]==='error').map(s=>`<div class="notice"><p>Профиль ${sideLabel(s)} недоступен. Независимые результаты другой стороны сохранены.</p><button class="text-button" data-action="retry-profile" data-side="${s}">Повторить ${sideLabel(s)} →</button></div>`).join('')}<table class="metric-table visual-environment"><caption class="sr-only">Визуальное сравнение окружения А/Б</caption><thead><tr><th scope="col">Рядом <small class="metric-note">Круг ${state.radius} м</small></th>${columns(sides)}</tr></thead><tbody>${ms.map(m=>`<tr class="${state.envFocus===m.id?'selected-row':''}"><td><button class="metric-name" data-action="visual-metric" data-metric="${m.id}" aria-expanded="${state.detail===m.id}">${icon(metricLabels[m.id][0],22)}<span>${metricLabels[m.id][1]}</span></button><span class="metric-caption">${metricLabels[m.id][2]}</span>${m.id==='stops'?`<button class="inline-limit" data-action="thresholds" data-goal="stops">До ${state.stopLimit} м ✎</button>`:''}</td>${sides.map(s=>`<td>${metricValue(m,s)}</td>`).join('')}</tr>${state.detail===m.id?`<tr class="metric-detail"><td colspan="${sides.length+1}"><div class="detail-grid"><div><strong>Как читать</strong>${m.method}</div><div><strong>Источник и актуальность</strong>${m.source}. Снимок demo-2026-10. Дата наблюдения неизвестна.<br><button class="text-button" data-action="sources">Полные сведения ↗</button></div></div></td></tr>`:''}`).join('')}</tbody></table>${compact?'<button class="text-button all-facts" data-action="tab" data-value="overview">Все показатели окружения →</button>':'<p class="metric-footnote">Тонкая отметка на нейтральной шкале — радиус анализа. Близость не означает «лучше». Парки и растительность не складываются.</p>'}`;
}
function overview(){return environmentView(false);}
function tripEntry(g,s,i){
  const key=`${s}:${g.id}`,t=selectedTrips()[key],tone=timeStatus(t,g);
  if(!t||t.status!=='available'){
    const pending=t?.status==='loading',refinement=t?.status==='refine';
    return `<td class="trip-cell visual-trip-cell unknown-cell"><span class="visual-unknown">${pending?'<span class="loader"></span>':icon('unknown',21)} ${pending?'Считаем':refinement?'Нужна улица':t?.status==='error'?'Сбой расчёта':'Нет расчёта'}</span>${t?.status==='error'?'<span class="metric-note">Маршрутизатор не ответил</span>':refinement?`<span class="metric-note">${state.refined[key+':start']?'Улица цели':'Улица старта'}</span>`:''}${thresholdBar(null,goalLimit(g),40,'unknown','Время поездки')}<button class="text-button" data-action="${refinement?'refine':'retry-trip'}" data-key="${key}" data-end="${state.refined[key+':start']?'target':'start'}" ${pending?'disabled':''}>${refinement?'Уточнить →':pending?'Подождите…':t?.status==='error'?'Повторить →':'Рассчитать →'}</button></td>`;
  }
  const max=Math.max(...selectedSides().map(side=>selectedTrips()[`${side}:${g.id}`]?.minutes||0),goalLimit(g));
  return `<td class="trip-cell visual-trip-cell ${state.selectedTrip===key?'selected':''}"><button class="trip-number" data-action="visual-route" data-key="${key}" aria-label="${sideLabel(s)} к цели ${escapeHTML(g.label)}: ${t.minutes} минут по модели, показать на карте"><strong class="metric-value">${t.minutes}<small>мин</small></strong><span class="status-dot ${tone}">${tone==='within'?'✓':'+'}</span></button>${thresholdBar(t.minutes,goalLimit(g),max*1.15,tone,'Модельное время уличной части')}<span class="visual-verdict ${tone}">${statusLabel(t,g)}</span><div class="cell-subline"><span>${t.km.toLocaleString('ru-RU')} км · модель</span><button data-action="trip-detail" data-key="${key}" aria-label="Детали поездки ${sideLabel(s)} к цели ${escapeHTML(g.label)}">ⓘ</button></div></td>`;
}
function tripTable(){
  const sides=selectedSides(),goals=selectedGoals();
  if(!goals.length)return `<div class="add-first-goal"><span>${icon('target',28)}</span><div><h4>Ваша повседневность — на карте</h4><p>Добавьте работу, учёбу или другое важное место.</p></div><button class="quiet" data-action="add-goal">＋ Добавить цель</button></div>`;
  return `<table class="metric-table trip-table visual-trip-table"><caption class="sr-only">Сравнение времени модели с вашими ориентирами</caption><thead><tr><th scope="col">Куда ездить<small class="metric-note">${state.mode==='walking'?'Пешком · улицы':'Авто · без пробок'}</small></th>${columns(sides)}</tr></thead><tbody>${goals.map((g,i)=>`<tr class="${state.focusGoal===g.id?'focused-row':''}" data-focus-row="${g.id}"><td><button class="visual-goal-name" data-action="focus-goal" data-goal="${g.id}" aria-pressed="${state.focusGoal===g.id}">${icon(goalIcon(g),23)}<strong>${escapeHTML(g.label)}</strong></button><button class="inline-limit" data-action="thresholds" data-goal="${g.id}">До ${goalLimit(g)} мин ✎</button></td>${sides.map(s=>tripEntry(g,s,i)).join('')}</tr>`).join('')}</tbody></table>`;
}
function tripDetailOnly(){
  const content=baseTripsView();const start=content.indexOf('<div class="trip-detail">');if(start<0)return '';
  const end=content.indexOf('<div class="trip-controls">',start);return content.slice(start,end);
}
function tripsView(){return `${tripTable()}${tripDetailOnly()}<div class="trip-controls"><button class="quiet" data-action="calculate">↻ Пересчитать</button><button class="text-button" data-action="clear-results">Очистить результаты</button></div><p class="metric-footnote">Время — модель уличной части, а не путь от двери до двери. Подходы неизвестны. Сбой одной ячейки не скрывает остальные.</p>`;}
function renderDock(active){document.querySelectorAll('.mobile-dock button').forEach(b=>{b.classList.toggle('selected',b.dataset.action===active);b.setAttribute('aria-pressed',b.dataset.action===active);});}
function renderResults(){
  renderDock(state.view==='map'?'dock-map':'dock-results');
  baseRenderResults();
  if(!selectedSides().length||state.scenario==='point')return;
  const sides=selectedSides(),places=state.scenario==='places';
  const tabs=places?[['summary','Обзор'],['trips','Поездки'],['overview','Рядом'],['data','Данные']]:[['trips','Поездки'],['data','Данные']];
  let body=state.tab==='summary'?`${selectedGoals().length?tripTable():''}${tripDetailOnly()}<div class="section-divider"><h4>${icon('park',20)} Окружение</h4><span>Факты, без оценок «хорошо / плохо»</span></div>${environmentView(true)}`:state.tab==='trips'?tripsView():state.tab==='overview'?overview():dataView();
  if(!places&&state.tab==='summary')body=tripsView();
  const legend=`<div class="reading-key"><span><i class="key-sample within"></i> В вашем ориентире</span><span><i class="key-sample over"></i> Дальше ориентира</span><span><i class="key-sample unknown"></i> Неизвестно</span><button data-action="thresholds">Настроить ✎</button></div>`;
  $('#result-content').innerHTML=`<div class="result-heading"><h3>${places?sides.length===2?'Сравните с первого взгляда':'Один адрес — подробный профиль':'От вашего старта'}</h3><button class="quiet visual-help" data-action="visual-help">${icon('info',17)} Как читать</button></div><div class="result-tabs" role="group" aria-label="Раздел результатов">${tabs.map(([id,label])=>`<button data-action="tab" data-value="${id}" class="${state.tab===id?'selected':''}" aria-pressed="${state.tab===id}">${label}</button>`).join('')}<button class="collapse" data-action="collapse" aria-expanded="${!state.collapsed}">${state.collapsed?'Развернуть ↓':'Свернуть ↑'}</button></div>${state.collapsed?'<button class="quiet" data-action="collapse">Развернуть сравнение ↓</button>':legend+body}<div class="model-disclosure">${icon('info',17)}<p>${state.mode==='walking'?'Пешком: показана только уличная часть, подходы от объектов неизвестны.':'Авто: модель без пробок, парковки и подтверждённых подъездов.'} <button data-action="sources">О данных ↗</button></p></div>`;
  $('#main').classList.toggle('map-view',state.view==='map');
}
function thresholds(focus=null){
  openDialog('Что удобно именно вам','Личные ориентиры · новая идея в демонстрационном макете',`<p class="threshold-intro">Двигайте отметки: карта и сравнение обновляются сразу. Числа поездок остаются результатами прежнего расчёта.</p><div class="threshold-settings">${selectedGoals().map(g=>`<div class="threshold-setting ${focus===g.id?'emphasized':''}"><div class="threshold-label">${icon(goalIcon(g),23)}<strong>${escapeHTML(g.label)}</strong><span>до <output data-output="${g.id}">${goalLimit(g)}</output> мин</span></div><input type="range" min="5" max="60" step="1" value="${goalLimit(g)}" aria-label="Ориентир для цели ${escapeHTML(g.label)} в минутах" data-limit-goal="${g.id}"><div class="range-labels"><span>5 мин</span><span>60 мин</span></div></div>`).join('')}${state.scenario==='places'?`<div class="threshold-setting ${focus==='stops'?'emphasized':''}"><div class="threshold-label">${icon('bus',23)}<strong>До остановки</strong><span>до <output data-output="stops">${state.stopLimit}</output> м</span></div><input type="range" min="100" max="1000" step="50" value="${state.stopLimit}" aria-label="Ориентир расстояния до остановки в метрах" data-stop-limit><div class="range-labels"><span>100 м</span><span>1 км</span></div></div>`:''}</div><div class="threshold-context">${icon('info',20)}<p>Минуты относятся к модели уличной части, метры до остановки — к прямому расстоянию. Это ваши ориентиры для чтения фактов, а не оценка качества адреса.</p></div>`,`<button class="primary" data-action="close-dialog">Готово ${icon('check',18)}</button>`);
}
function demo(type='filled'){
  baseDemo(type==='loading'?'filled':type);state.tab=type==='partial'?'summary':'summary';state.focusGoal=null;state.envFocus=null;state.mapMode='all';state.limits={};state.stopLimit=250;
  if(type==='filled')Object.entries(state.trips).forEach(([key,t])=>{if(t.status==='refine'){t.status='available';state.refined[key+':start']=true;}});
  if(type==='loading'){state.trips={};calculate();state.tab='summary';}
  state.mobileConfigure=false;render();$('.sidebar').scrollTop=0;
}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-action]');if(!b||b.disabled)return;const action=b.dataset.action;
  if(!['thresholds','focus-goal','clear-focus','map-mode','visual-metric','visual-route','visual-help','mobile-settings','dock-map','dock-results','dock-settings'].includes(action))return;
  e.stopImmediatePropagation();e.preventDefault();
  if(action==='mobile-settings'){state.mobileConfigure=!state.mobileConfigure;state.mobileSetup=true;renderSetup();return;}
  if(action.startsWith('dock-')){if(action==='dock-settings'){state.mobileConfigure=true;state.mobileSetup=true;renderSetup();$('.sidebar').scrollIntoView({behavior:'smooth',block:'start'});renderDock('dock-settings');}else {state.view=action==='dock-map'?'map':'results';renderResults();$(action==='dock-map'?'.map-section':'#results').scrollIntoView({behavior:'smooth',block:'start'});}return;}
  if(action==='thresholds'){thresholds(b.dataset.goal);return;}
  if(action==='focus-goal'){const scope=b.closest('.map')?'.map':'.trip-table';state.focusGoal=state.focusGoal===b.dataset.goal?null:b.dataset.goal;state.envFocus=null;state.selectedTrip=null;renderMap();renderResults();$(`${scope} [data-action="focus-goal"][data-goal="${b.dataset.goal}"]`)?.focus({preventScroll:true});if(state.view==='map')toast('Та же цель подсвечена в сравнении.');return;}
  if(action==='clear-focus'){state.focusGoal=null;state.selectedTrip=null;state.envFocus=null;renderMap();renderResults();return;}
  if(action==='map-mode'){state.mapMode=b.dataset.value;if(state.mapMode==='selected'&&!state.focusGoal&&!state.selectedTrip)state.focusGoal=selectedGoals()[0]?.id;renderMap();renderResults();return;}
  if(action==='visual-route'){state.selectedTrip=b.dataset.key;state.focusGoal=b.dataset.key.split(':')[1];state.envFocus=null;renderMap();renderResults();if(innerWidth<=760){state.view='map';renderResults();$('.map-section').scrollIntoView({behavior:'smooth',block:'start'});}else $('.map-section').scrollIntoView({behavior:'smooth',block:'start'});return;}
  if(action==='visual-metric'){state.envFocus=b.dataset.metric;state.detail=state.detail===b.dataset.metric?null:b.dataset.metric;state.focusGoal=null;renderMap();renderResults();$(`[data-action="visual-metric"][data-metric="${b.dataset.metric}"]`)?.focus({preventScroll:true});return;}
  if(action==='visual-help'){openDialog('Меньше чтения — больше ясности','Карта и сравнение говорят на одном языке',`<div class="help-visual-row"><span class="status-dot within">✓</span><p><strong>Зелёная шкала</strong> — значение укладывается в ваш ориентир.</p></div><div class="help-visual-row"><span class="status-dot over">+</span><p><strong>Оранжевая часть</strong> — насколько значение выходит за отметку. Это не общий вердикт об адресе.</p></div><div class="help-visual-row"><span class="status-dot unknown">?</span><p><strong>Штриховка и вопрос</strong> — данных нет. Ноль здесь не подставляется.</p></div><p>Нажмите на работу или спорт: та же цель выделится на карте и в таблице. Нажмите на число минут — откроется его уличная линия.</p><p>Нейтральные шкалы парков, дорог и воды показывают расстояния на общей шкале. Они не оценивают качество места.</p><div class="threshold-context"><p>Пороги — новая демонстрационная идея. В рабочем PlaceLens они пока не реализованы. Общего рейтинга и автоматического победителя нет.</p></div>`);}
},true);
document.addEventListener('input',e=>{
  const input=e.target;if(!input.matches('[data-limit-goal],[data-stop-limit]'))return;
  if(input.hasAttribute('data-stop-limit')){state.stopLimit=Number(input.value);$('[data-output="stops"]').value=input.value;}
  else {const g=selectedGoals().find(g=>g.id===input.dataset.limitGoal);if(!g)return;state.limits[limitKey(g)]=Number(input.value);$(`[data-output="${g.id}"]`).value=input.value;}
  renderMap();renderResults();
});
document.addEventListener('close',()=>{const old=document.activeElement;const action=old?.dataset?.action,goal=old?.dataset?.goal;renderSetup();if(action){const next=[...document.querySelectorAll(`[data-action="${action}"]`)].find(x=>x.dataset.goal===goal);next?.focus({preventScroll:true});}},true);
let responsiveTimer;window.addEventListener('resize',()=>{clearTimeout(responsiveTimer);responsiveTimer=setTimeout(renderMap,90);});
document.querySelector('.top-actions .demo-label').innerHTML='<i></i> Демо · ориентиры — гипотеза';
const startup=new URLSearchParams(location.search).get('demo');
if(startup==='empty')render();else demo(startup==='partial'?'partial':'filled');
